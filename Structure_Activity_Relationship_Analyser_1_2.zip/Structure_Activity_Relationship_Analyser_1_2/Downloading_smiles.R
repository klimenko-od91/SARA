## Status bar
svalue(status_bar) <- "Uploading..."

## Downloading smiles 
df <- read.table(svalue(sometext_smiles), header=FALSE, sep="\t", check.names=FALSE, 
           as.is=TRUE, comment.char="", quote="", row.names=NULL)

# making the function to count elements
countCharOccurrences <- function(char, attempt) {
  attempt2 <- gsub(char,"",attempt)
  return (nchar(attempt) - nchar(attempt2))
}
### do not forget that function counts characters
Brdesc <- countCharOccurrences("Br",df[1:nrow(df),1])
Brdesc <- Brdesc/2
Cldesc <- countCharOccurrences("Cl",df[1:nrow(df),1])
Cldesc <- Cldesc/2
Ndesc <- countCharOccurrences("N",df[1:nrow(df),1])
Odesc <- countCharOccurrences("O",df[1:nrow(df),1])
Pdesc <- countCharOccurrences("P",df[1:nrow(df),1])
Sidesc <- countCharOccurrences("Si",df[1:nrow(df),1])
Sidesc <- Sidesc/2
Sdesc <- countCharOccurrences("S",df[1:nrow(df),1])
Sdesc <- Sdesc - Sidesc
Fdesc <- countCharOccurrences("F",df[1:nrow(df),1])
Idesc <- countCharOccurrences("I",df[1:nrow(df),1])
Bdesc <- countCharOccurrences("B",df[1:nrow(df),1])
Bdesc = Bdesc - Brdesc
Cdesc <- countCharOccurrences("C",df[1:nrow(df),1])
Cdesc = Cdesc - Cldesc
ar.Cdesc <- countCharOccurrences("c",df[1:nrow(df),1])
ar.Odesc <- countCharOccurrences("o",df[1:nrow(df),1])
ar.Ndesc <- countCharOccurrences("n",df[1:nrow(df),1])
ar.Sdesc <- countCharOccurrences("s",df[1:nrow(df),1])
Haldesc <- Brdesc+Cldesc+Fdesc+Idesc
SybylO2desc <- countCharOccurrences("=O",df[1:nrow(df),1])+countCharOccurrences("O=",df[1:nrow(df),1])
SybylO2desc <- SybylO2desc/2 #ec
Nitrildesc <-  countCharOccurrences("C#N",df[1:nrow(df),1])+countCharOccurrences("N#C",df[1:nrow(df),1])
Nitrildesc <- Nitrildesc/3
SybylS2desc <- countCharOccurrences("=S",df[1:nrow(df),1])+countCharOccurrences("S=",df[1:nrow(df),1])
SybylS2desc <- SybylS2desc/2 
Triplebondesc <- countCharOccurrences("#",df[1:nrow(df),1])

DASHdesc <- countCharOccurrences("@@",df[1:nrow(df),1])
WEDGEdesc <- countCharOccurrences("@",df[1:nrow(df),1])
WEDGEdesc <- WEDGEdesc-DASHdesc
DASHdesc <- DASHdesc/2
Stereocentdesc <- DASHdesc+WEDGEdesc

extractcyclic <- regmatches(df[1:nrow(df),1], gregexpr("[0-9]", df[1:nrow(df),1]))
#extractcyclic <- regmatches(df[1:nrow(df),1], gregexpr("[0-9]+", df[1:nrow(df),1]))

cyclnumber <- 0

for (i in 1:nrow(df)) 
{ 
  
  cyclnumber[i] <- as.numeric(length(as.numeric(unlist(extractcyclic[i])))/2)
  
}

cyclnumber[which(cyclnumber == "-Inf")] <- 0


## adding descriptors to the data frame
descriptors <- data.frame(Bdesc, Brdesc, Cdesc, Cldesc, Fdesc, Idesc, Ndesc, Odesc, Pdesc, Sdesc, Sidesc, 
                            ar.Cdesc, ar.Odesc, ar.Ndesc, ar.Sdesc, SybylO2desc, SybylS2desc,
                          Haldesc, Nitrildesc, Triplebondesc, Stereocentdesc, cyclnumber)
df <- data.frame(df, descriptors)

## ordering by activity
#df <- as.data.frame(df[order(df[,3], decreasing = TRUE), ])

## removing smiles string & splitting the activity from descriptors
Smiles_string <- data.frame(df[,2],df[,1])
property <- df[,3]
df[,3] <- NULL
df[,1] <- NULL


new_window <- gwindow(title = "Data Table", 
                      visible = TRUE, handler = NULL, toolkit = guiToolkit())

df_gtable <- gtable(df, container = new_window, handler = function(h,...) 
{dispose(h$obj)}, toolkit = guiToolkit())

svalue(status_bar) <- ""