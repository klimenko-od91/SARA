svalue(status_bar) <- "Calculating..."

## removing the zero values columns
zerocolsumns <- which(colSums(df[,2:ncol(df)]) == "0")
df <- df[, !(names(df) %in% names(zerocolsumns))]

### Euclidean distance matrix

## normalizing data
training_centered <- as.data.frame(scale(df[,2:ncol(df)]))

## Calculating distance
Distance_matrix_training <- as.matrix(dist(training_centered, 
method = "euclidean", diag = FALSE, upper = FALSE))
Distance_matrix <- data.frame(df[,1], Distance_matrix_training)
colnames(Distance_matrix) <- c("Names",df[,1])

new_window <- gwindow(title = "Distance Matrix", 
visible = TRUE, handler = NULL, toolkit = guiToolkit())

Distance_matrix_gtable <- gtable(Distance_matrix, 
container = new_window, handler = function(h,...) 
{dispose(h$obj)}, toolkit = guiToolkit())

svalue(status_bar) <- ""

