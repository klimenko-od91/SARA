svalue(status_bar) <- "Calculating..."

zerocolsumns <- which(colSums(df[,2:ncol(df)]) == "0")
df <- df[, !(names(df) %in% names(zerocolsumns))]

Tanimoto_function <- function(row1,row2) {
  Tanimoto_sim <- 0
  Tanimoto_nom <- 0
  Tanimoto_denom <- 0
  for(i in 2:ncol(df)) {
    
  Tanimoto_nom[i] <- min(df[row1,i], df[row2,i])
  Tanimoto_denom[i] <- max(df[row1,i], df[row2,i])
  Tanimoto_sim <- sum(Tanimoto_nom)/sum(Tanimoto_denom)
  }
  return(Tanimoto_sim)
}

Tanimoto_matrix <- matrix(NA, nrow=nrow(df),ncol=nrow(df),dimnames=list(df[,1],df[,1]))
for (i in 1:nrow(df)) {
  for(j in 1:nrow(df)) {
    Tanimoto_matrix[i,j] <- Tanimoto_function(i,j)
    Tanimoto_matrix[j,i] = Tanimoto_matrix[i,j]
}
}

Chembl_rows <- as.data.frame(rownames(Tanimoto_matrix), row.names = rownames(Tanimoto_matrix))
colnames(Chembl_rows) <- c("Name")
Tanimoto_matrix <- data.frame(Chembl_rows,
Tanimoto_matrix,row.names = rownames(Tanimoto_matrix))
new_window <- gwindow(title = "Tanimoto Matrix", 
                      visible = TRUE, handler = NULL, toolkit = guiToolkit())

Tanimoto_matrix_gtable <- gtable(Tanimoto_matrix, 
                                 container = new_window, handler = function(h,...) 
                                 {dispose(h$obj)}, toolkit = guiToolkit())

svalue(status_bar) <- ""
