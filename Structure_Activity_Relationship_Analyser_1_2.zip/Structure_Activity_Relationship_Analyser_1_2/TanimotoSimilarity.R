## Status bar

svalue(status_bar) <- "Calculating..."

## removing the zero values columns

zerocolsumns <- which(colSums(df[,2:ncol(df)]) == "0")
df <- df[, !(names(df) %in% names(zerocolsumns))]

## specifying the reference compound
reference_compound <- as.numeric(rownames(df[which
                                             (df[,1] == svalue(Tanimoto_compound_selection)), ]))

## Tanimoto calculation for reference compound

if (svalue(Reference_gradio) ==  "Tanimoto") { 

x <- 0
y <- 0
Tanimoto <- 0
rownames(df) <- NULL

for (j in 1:nrow(df))

{
  
for (i in 2:ncol(df))
{x[i] <- max(df[reference_compound,i], df[j,i])
  }
for (i in 2:ncol(df))
{y[i] <- min(df[reference_compound,i], df[j,i])
} 

Tanimoto[j] <- sum(y)/sum(x)}

Tanimoto <- as.data.frame(Tanimoto)
Tanimoto[,2] <- Tanimoto 
Tanimoto[,1] <- df[,1]
colnames(Tanimoto) <- c("",df[reference_compound,1]) 
Tanimoto_filename <- paste("Ts_",df[reference_compound,1],".csv",
 sep ="")


new_window <- gwindow(title = "Tanimoto Similarity", 
visible = TRUE, handler = NULL, toolkit = guiToolkit())

Tanimoto_gtable <- gtable(Tanimoto, 
container = new_window, handler = function(h,...) 
{dispose(h$obj)}, toolkit = guiToolkit())

#svalue(status_bar) <- ""


                } else {

## Euclidean distance calculation for reference compound

training_centered <- as.data.frame(scale(df[,2:ncol(df)]))

xyz <- 0
euclid_distance <- 0


for (j in 1:nrow(df))
{
  for (i in 1:ncol(training_centered))
  {xyz[i] <- (training_centered[reference_compound,i] - training_centered[j,i])**2}
  
  euclid_distance[j] <- sqrt(sum(xyz)) }

euclid_distance <- as.data.frame(euclid_distance)
euclid_distance[,2] <- euclid_distance 
euclid_distance[,1] <- df[,1]
colnames(euclid_distance) <- c("",df[reference_compound,1])

Euclidean_filename <- paste("Dist_",df[reference_compound,1],".csv",
                           sep ="")

new_window <- gwindow(title = "Euclidean distance", 
                      visible = TRUE, handler = NULL, toolkit = guiToolkit())

Tanimoto_gtable <- gtable(euclid_distance, 
                          container = new_window, handler = function(h,...) 
                          {dispose(h$obj)}, toolkit = guiToolkit())

}

svalue(status_bar) <- ""



