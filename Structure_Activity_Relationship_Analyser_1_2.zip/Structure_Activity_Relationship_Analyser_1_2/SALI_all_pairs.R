## Selecting directory
new_dir <- gfile(type = "selectdir")
setwd(new_dir)

svalue(status_bar) <- "Calculating..."

## Calculations (depends on the metrics choice)

if (svalue(SALI_allpairs_gradio) ==  "Tanimoto") {



Tanimoto_matrix[,1] <- NULL

## Calculating SALI for all pairs

SALI_all_pairs <- matrix(NA, nrow=nrow(df),ncol=nrow(df),dimnames=list(df[,1],df[,1]))
for (i in 1:nrow(df)) {
  for(j in 1:nrow(df)) {

SALI_all_pairs[i,j] <- abs(property[i] - property[j]) / (1-Tanimoto_matrix[i,j])

	}
		}

SALI_all_pairs <- data.frame(Chembl_rows,
SALI_all_pairs,row.names = rownames(SALI_all_pairs))

new_window <- gwindow(title = "SALI all pairs", 
                      visible = TRUE, handler = NULL, toolkit = guiToolkit())

SALI_allpairs_gtable <- gtable(SALI_all_pairs, 
                                 container = new_window, handler = function(h,...) 
                                 {dispose(h$obj)}, toolkit = guiToolkit())

## changing SALI matrix into the vector 

SALI_unlist <- unlist(SALI_all_pairs[,2:ncol(SALI_all_pairs)])

## here is coeffitient for SALI categorization

sigma_SALI <- as.numeric(svalue(all_pairs_sigmaC_SALI))

## threshold and category calculations for all pairs SALI threshold

SALI_threshold_all_pairs <- mean(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)])+ 
sigma_SALI*sd(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)])

## Detecting highest SALIs

SALI_T_F <- as.data.frame(SALI_threshold_all_pairs < SALI_all_pairs[2:ncol(SALI_all_pairs)])

SALI_T_F <- data.frame(SALI_all_pairs[,1], SALI_T_F)

## Finding the most discontinious compounds

Most_discontinious <- 0

for (i in 2:ncol(SALI_T_F)) {

Most_discontinious[i] <- length(SALI_T_F[which(SALI_T_F[,i] == 'TRUE'),      i])

}

## here is sigma coefficient for compounds categorization

sigma_cmp <- as.numeric(svalue(all_pairs_sigmaC_comp))

## threshold and category calculations for compounds

Most_discontinious  <- data.frame(colnames(SALI_T_F), Most_discontinious, row.names = colnames(SALI_T_F))

Most_discontinious_threshold <- sigma_cmp*sd(Most_discontinious[,2]) +  mean(Most_discontinious[,2]) # maybe 2sigma is a better option

important_compounds <- as.data.frame(Most_discontinious_threshold < Most_discontinious[,2], row.names = rownames(Most_discontinious) )

Most_discontinious[,3]  <- important_compounds

Most_discontinious  <- Most_discontinious[order(Most_discontinious[2], decreasing = TRUE),]

SALI_all_pairs_details <- as.data.frame (c(SALI_threshold_all_pairs, 
sigma_SALI, sd(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)]), 
mean(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)]),
Most_discontinious_threshold, 
sigma_cmp,sd(Most_discontinious[,2]),
mean(Most_discontinious[,2]) ), row.names = c("Threshold for SALI", "Standard dev. coef (SALI)", "Standard dev. (SALI)", "Average (SALI)", 
"Threshold for compound selection", "Standard dev. coef (Comp. sel.)", "Standard dev. coef (Comp. sel.)", "Average (Comp. sel.)")
  )

colnames(SALI_all_pairs_details) <- NULL
colnames(Most_discontinious) <- c("ID", "Number of cliffs", "Number of cliffs above threshold")

## output for categorizing all pairs

write.csv(SALI_all_pairs, file = "SALI_all_pairs.csv") 

write.csv(SALI_T_F, file = "SALI_all_pairs_categorized.csv")

write.csv(SALI_all_pairs_details, file = "SALI_category_details.csv", row.names = TRUE) ## parameters should be given in the separate file

write.csv(Most_discontinious, file = "Compounds_activity_cliff_count.csv")

### Plotting SALI curve

png(file = paste("SALI_plot_all_pairs.png")
,width=400, height=500)

plot(sort(SALI_unlist, decreasing = TRUE), type = "l", main = "SALI Distribution",
  ylab = "SALI", xlab = "number of compounds", xlim = c(0, length(SALI_unlist)), col = "orange")

dev.off()

} else { 

Distance_matrix[,1] <- NULL

## Calculating SALId for all pairs

SALId_all_pairs <- matrix(NA, nrow=nrow(df),ncol=nrow(df),dimnames=list(df[,1],df[,1]))
for (i in 1:nrow(df)) {
  for(j in 1:nrow(df)) {

SALId_all_pairs[i,j] <- abs(property[i] - property[j]) / Distance_matrix[i,j]

	}
		}

SALId_all_pairs <- data.frame(colnames(SALId_all_pairs),
SALId_all_pairs,row.names = rownames(SALId_all_pairs))

colnames(SALId_all_pairs)[1] <- "Name"

new_window <- gwindow(title = "SALId all pairs", 
                      visible = TRUE, handler = NULL, toolkit = guiToolkit())

SALId_allpairs_gtable <- gtable(SALId_all_pairs, 
                                 container = new_window, handler = function(h,...) 
                                 {dispose(h$obj)}, toolkit = guiToolkit())

## changing SALId matrix into the vector 

SALI_unlist <- unlist(SALId_all_pairs[,2:ncol(SALId_all_pairs)])

## here is coeffitient for SALI categorization

sigma_SALI <- as.numeric(svalue(all_pairs_sigmaC_SALI))

## threshold and category calculations for all pairs SALId threshold

SALI_threshold_all_pairs <- mean(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)])+ 
sigma_SALI*sd(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)])

## Detecting highest SALIds

SALI_T_F <- as.data.frame(SALI_threshold_all_pairs < SALId_all_pairs[2:ncol(SALId_all_pairs)])

SALI_T_F <- data.frame(SALId_all_pairs[,1], SALI_T_F)


## Finding the most discontinious compounds

Most_discontinious <- 0

for (i in 2:ncol(SALI_T_F)) {

Most_discontinious[i] <- length(SALI_T_F[which(SALI_T_F[,i] == 'TRUE'),      i])

}

## here is sigma coefficient for compounds categorization

sigma_cmp <- as.numeric(svalue(all_pairs_sigmaC_comp))

## threshold and category calculations for compounds

Most_discontinious  <- data.frame(colnames(SALI_T_F), Most_discontinious, row.names = colnames(SALI_T_F))

Most_discontinious_threshold <- sigma_cmp*sd(Most_discontinious[,2]) +  mean(Most_discontinious[,2]) # maybe 2sigma is a better option

important_compounds <- as.data.frame(Most_discontinious_threshold < Most_discontinious[,2], row.names = rownames(Most_discontinious) )

Most_discontinious[,3]  <- important_compounds

Most_discontinious  <- Most_discontinious[order(Most_discontinious[2], decreasing = TRUE),]

SALId_all_pairs_details <- as.data.frame (c(SALI_threshold_all_pairs, 
sigma_SALI, sd(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)]), 
mean(SALI_unlist[!is.nan(SALI_unlist) & !is.infinite(SALI_unlist)]),
Most_discontinious_threshold, 
sigma_cmp,sd(Most_discontinious[,2]),
mean(Most_discontinious[,2]) ), row.names = c("Threshold for SALId", "Standard dev. coef (SALId)", "Standard dev. (SALId)", "Average (SALId)", 
"Threshold for compound selection", "Standard dev. coef (Comp. sel.)", "Standard dev. coef (Comp. sel.)", "Average (Comp.sel.)")
  )

colnames(SALId_all_pairs_details) <- NULL
colnames(Most_discontinious) <- c("ID", "Number of cliffs", "Number of cliffs above threshold")

## output for categorizing all pairs

write.csv(SALId_all_pairs, file = "SALId_all_pairs.csv") 

write.csv(SALI_T_F, file = "SALId_all_pairs_categorized.csv")

write.csv(SALId_all_pairs_details, file = "SALId_category_details.csv", row.names = TRUE) ## parameters should be given in the separate file

write.csv(Most_discontinious, file = "Compounds_activity_cliff_count_SALId.csv")


### Plotting SALId curve

png(file = paste("SALId_plot_all_pairs.png")
,width=400, height=500)

plot(sort(SALI_unlist, decreasing = TRUE), type = "l", main = "SALI Distribution",
  ylab = "SALId", xlab = "number of compounds", xlim = c(0, length(SALI_unlist)), col = "orange")

dev.off()

	}

svalue(status_bar) <- ""

