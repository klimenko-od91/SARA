## remove the previous workspace

rm(list = ls())

## load libraries

library("gWidgets") 
library("gWidgetstcltk")
library("grDevices")
library("stats")

## set global graphic toolkit
options(guiToolkit="tcltk") 

## Defining working directory - consider revising
working_dir <- getSrcDirectory(function(x) {x})
setwd(working_dir)


## Create dialog window

win <- gwindow(title = "Structure-Activity Relationship Analyser v1.2", 
		visible = TRUE, handler = NULL, toolkit = guiToolkit())

status_bar <- gstatusbar("", container = win)
grp_name <- ggroup(container = win)
grp_name_subset1 <- ggroup( pos = 2, container = win)
grp_name_subset2 <- ggroup(container = win)
grp_name2 <- ggroup(container = win)
grp_name2_1 <- ggroup(container = win)
grp_name2_2 <- ggroup(container = win)  
grp_name3 <- ggroup(container = win)  
grp_name4 <- ggroup(container = win)
grp_name5 <- ggroup(container = win)
grp_name_table <- ggroup(container = win)

## Create widgets for descriptors or smiles upload

Descriptor_selection_button <- gbutton("Descriptors file selection", border = TRUE, container = grp_name, 
                         handler = function(h,...) {svalue(sometext)<- gfile(type = "open")})

sometext <- gedit(text = "" , width = 25, coerce.with = NULL, initial.msg="",
                  handler = NULL
			, action = NULL, container = grp_name, toolkit = guiToolkit())

upload_button <- gbutton("Upload", border = TRUE, container = grp_name, 
                         handler = function(h,...) {source("readtableScript.R")})

OR_label <- glabel(text = "OR", handler = NULL, container = grp_name_subset1)

SMILES_selection_button <- gbutton("SMILES file selection", border = TRUE, container = grp_name_subset2, 
                         handler = function(h,...) {svalue(sometext_smiles)<- gfile(type = "open")})

sometext_smiles <-  gedit(text = "" , width = 28, coerce.with = NULL, initial.msg="", 
				handler = NULL,
				 action = NULL, container = grp_name_subset2, toolkit = guiToolkit())

upload_button_smiles <- gbutton("Upload", border = TRUE, container = grp_name_subset2, 
                         handler = function(h,...) {source("Downloading_smiles.R")})
save_button_smiles <- gbutton("Save", border = TRUE, container = grp_name_subset2, handler = function(h, ...)
{write.csv(df, file = gfile(type = "save", initialfilename = "SARA_descriptors.csv") )})

## Tanimoto similarity matrix
TanimotoMatrix_label <- glabel(text = "Tanimoto Matrix", handler = NULL, container = grp_name2_1)

TanimotoMatrix_button <- gbutton("Calculate", border = TRUE, container = grp_name2_1, handler = function(h, ...)
{source("Tanimoto_matrix.R")})

save_TanimotoMatrix_button <- gbutton("Save", border = TRUE, container = grp_name2_1, handler = function(h, ...)
{write.csv(Tanimoto_matrix, file = gfile(type = "save", initialfilename = "Tanimoto_Matrix.csv") )})

## Euclidean distnce matrix 
DistanceMatrix_label <- glabel(text = "Distance Matrix", handler = NULL, container = grp_name2)

DistanceMatrix_button <- gbutton("Calculate", border = TRUE, container = grp_name2, handler = function(h, ...)
{source("DistanceMatrix.R")})

save_DistanceMatrix_button <- gbutton("Save", border = TRUE, container = grp_name2, handler = function(h, ...)
{write.csv(Distance_matrix, file = gfile(type = "save", initialfilename = "Distance_Matrix.csv") )})

## SALI allpairs calculation

SALI_allpair_label <- glabel(text = "all possible SALI ", 
handler = NULL, container = grp_name2_2)

SALI_allpairs_choices <- c("Tanimoto", "Distance")
SALI_allpairs_gradio <- gradio(SALI_allpairs_choices, container = grp_name2_2)

SALI_alpairs_button <- gbutton("Calculate", border = TRUE, container = grp_name2_2, handler = function(h, ...)
{source("SALI_all_pairs.R")}) 

all_pairs_sigmaC_SALI_label <- glabel(text = "coef A", handler = NULL, container = grp_name2_2)

all_pairs_sigmaC_SALI <- gedit(text = "3" , width = 5, coerce.with = NULL, initial.msg="",
                  handler = NULL
			, action = NULL, container = grp_name2_2, toolkit = guiToolkit())

all_pairs_sigmaC_comp_label <- glabel(text = "coef B", handler = NULL, container = grp_name2_2)

all_pairs_sigmaC_comp <- gedit(text = "1" , width = 5, coerce.with = NULL, initial.msg="",
                  handler = NULL
			, action = NULL, container = grp_name2_2, toolkit = guiToolkit())

## Tanimoto with ref. calculation 
Tanimoto_label <- glabel(text = "Reference compound", handler = NULL, container = grp_name3)

Tanimoto_compound_selection <- gedit(text = "" , width = 25, coerce.with = NULL, initial.msg="Enter mol name",
                  handler = NULL, action = NULL, container = grp_name3, toolkit = guiToolkit())

Reference_choices <- c("Tanimoto", "Distance")
Reference_gradio <- gradio(Reference_choices, container = grp_name3)

Tanimoto_button <- gbutton("Calculate", border = TRUE, container = grp_name3, handler = function(h, ...)
{source("TanimotoSimilarity.R")})

save_Tanimoto_button <- gbutton("Save", border = TRUE, container = grp_name3, handler = function(h, ...)
{ if (svalue(Reference_gradio) ==  "Tanimoto") {
write.csv(Tanimoto, file = gfile(type = "save", initialfilename = Tanimoto_filename)) 
			} else {
write.csv(euclid_distance, file = gfile(type = "save", initialfilename = Euclidean_filename)) }
})

## SALI calculation

SALI_label <- glabel(text = "Structure-Activity Landscape Index(SALI)", 
handler = NULL, container = grp_name4)

SALI_choices <- c("Tanimoto", "Distance")
SALI_gradio <- gradio(SALI_choices, container = grp_name4)

SALI_button <- gbutton("Calculate", border = TRUE, container = grp_name4,
 
handler = function(h, ...)
{ if (svalue(SALI_gradio) == "Tanimoto") {source("SALI.R")}

else {source("SALI_alt.R")}
})

save_SALI_button <- gbutton("Save", border = TRUE, container = grp_name4, handler = function(h, ...)
{write.csv(SALI, file = gfile(type = "save", initialfilename = SALI_filename) )})


## Plotting

Plot_label <- glabel(text = "Structure-Activity Visualisation", 
handler = NULL, container = grp_name5)

Plot_button <- gbutton("Plot", border = TRUE, container = grp_name5, handler = function(h, ...)
{source("SALI_plotting.R")})

size(DistanceMatrix_button) <- c(100,50)
size(upload_button) <- c(100,50)
size(Tanimoto_button) <- c(100,50)
size(SALI_button) <- c(100,50)
size(Plot_button) <- c(100,50)
size(upload_button_smiles) <- c(100,50)
