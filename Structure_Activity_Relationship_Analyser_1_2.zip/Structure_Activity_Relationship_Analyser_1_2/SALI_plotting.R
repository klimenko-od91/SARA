## original working directory

original_dir <- getwd()

## Selecting directory
new_dir <- gfile(type = "selectdir")
setwd(new_dir)

## Status bar

svalue(status_bar) <- "Plotting..."


## calculating least common descriptor

descdiff <- as.data.frame(matrix(NA, nrow=nrow(df),ncol=ncol(df),
dimnames=list(df[,1],colnames(df)) ) )

for (j in 1:nrow(df))

{
  
for (i in 2:ncol(df))
{descdiff[j,i] <- abs(df[reference_compound,i] - df[j,i]) }
  }


descdiff[,1] <- NULL

which_name <- 0

for (j in 1:nrow(df))

{

which_name[j] <- names(which.max(descdiff[j,] ) )


}

least_common_descriptor <- data.frame(df[,1], which_name)

## Mapping


if (svalue(SALI_gradio) ==  "Tanimoto") { 

## SALI curve

png(file = paste("SALI_plot_",df[reference_compound,1],".png")
,width=400, height=500)

plot(SALI[,1], type = "l", main = "SALI Distribution",
  ylab = "SALI", xlab = "number of compounds", xlim = c(0, length(SALI[,1])), col = "orange")

dev.off()

## four-panel plot  - Tanimoto

vector_values <- function(Value) {
line_vector <- vector(mode = "numeric", length = length(Tanimoto[,2]))
line_vector[1:length(Tanimoto[,2])] <- Value
return(line_vector) } 

average_shift <- mean(c(min(property-property[reference_compound]),
max(property-property[reference_compound]) ) )

xaxis <- vector_values(0.5)
yaxis <- vector_values(average_shift)

png(file = paste("SA_chart_",df[reference_compound,1],".png")
,width=400, height=500)

SALI_plot <- plot(x = Tanimoto[,2], y = property-property[reference_compound],
	type = "p", 
	main = "Structure-Activity Chart", 
	ylab = "Activit change", xlab = paste("Tanimoto ",df[reference_compound,1], sep =""),
   	col = "red")

lines(xaxis, property-property[reference_compound], col = "black")
lines(Tanimoto[,2], yaxis, col = "black")

dev.off()

## splitting compounds into categories

SALI_categorized <- data.frame(df[,1],
 property-property[reference_compound],
 Tanimoto[,2])
colnames(SALI_categorized) <- c("Name", "Activity shift",
paste("Tanimoto ",df[reference_compound,1],sep ="") ) 

output_category1 <- 0
output_category2 <- 0
output_category3 <- 0
output_category4 <- 0

for (i in 1:nrow(SALI_categorized)) {
  
if (SALI_categorized[i,2] >= average_shift && SALI_categorized[i,3] >= 0.5)
{ output_category2[i] <- as.character(SALI_categorized[i,1]) } 
  
if (SALI_categorized[i,2] >= average_shift && SALI_categorized[i,3] <= 0.5) 
  { output_category1[i] <- as.character(SALI_categorized[i,1]) } 
 
if (SALI_categorized[i,2] <= average_shift && SALI_categorized[i,3] <= 0.5) 
  { output_category3[i] <- as.character(SALI_categorized[i,1]) } 
   
if (SALI_categorized[i,2] <= average_shift && SALI_categorized[i,3] >= 0.5) 
  {output_category4[i] <- as.character(SALI_categorized[i,1])} 
}   

## remove NAs and zeros
output_category1 <- output_category1[output_category1 != 0 & !is.na(output_category1)]
output_category2 <- output_category2[output_category2 != 0 & !is.na(output_category2)]
output_category3 <- output_category3[output_category3 != 0 & !is.na(output_category3)]
output_category4 <- output_category4[output_category4 != 0 & !is.na(output_category4)]


## Overall output

Overall_output <- data.frame( SALI_categorized[ order(SALI_categorized[,1]),   ],
SALI[order(SALI[,2]),1],
Smiles_string[order(Smiles_string[,1]),2 ],
least_common_descriptor[order(least_common_descriptor[,1]), 2]   )

colnames(Overall_output) <- c(colnames(SALI_categorized), "SALI", "SMILES string", "least common descriptor") 

## the threshold value

SALI_threshold <- mean(SALI[!is.nan(SALI[,1]) & !is.infinite(SALI[,1]),1])+ 
sd(SALI[!is.nan(SALI[,1]) & !is.infinite(SALI[,1]),1])

## selecting the most discontinuous 

highest_SALI <- data.frame(SALI[SALI[,1] > SALI_threshold,], SALI_threshold)


## saving everything

Mapping_results1_filename <- paste("Mapping_results_", df[reference_compound,1],
 "_cat1", ".csv", sep ="")
Mapping_results2_filename <- paste("Mapping_results_",df[reference_compound,1],
 "_cat2", ".csv", sep ="")
Mapping_results3_filename <- paste("Mapping_results_",df[reference_compound,1],
 "_cat3", ".csv", sep ="")
Mapping_results4_filename <- paste("Mapping_results_",df[reference_compound,1], 
 "_cat4", ".csv", sep ="")
Overall_results_filename <- paste("Overall_results_",df[reference_compound,1], 
  ".csv", sep ="")
highest_SALI_filename <- paste("highest_SALI_",df[reference_compound,1], 
  ".csv", sep ="")


write.csv(output_category1, file = Mapping_results1_filename)
write.csv(output_category2, file = Mapping_results2_filename)
write.csv(output_category3, file = Mapping_results3_filename)
write.csv(output_category4, file = Mapping_results4_filename)
write.csv(Overall_output, file = Overall_results_filename)
write.csv(highest_SALI, file = highest_SALI_filename)

  } else { 

## SALI curve

png(file = paste("Dist_SALI_plot_",df[reference_compound,1],".png")
,width=400, height=500)

plot(SALI[,1], type = "l", main = "SALI Distribution",
  ylab = "SALI", xlab = "number of compounds", xlim = c(0, length(SALI[,1])), col = "blue")

dev.off()

## four-panel plot  - Distance

vector_values <- function(Value) {
line_vector <- vector(mode = "numeric", length = length(property))
line_vector[1:length(property)] <- Value
return(line_vector) } 

average_shift <- mean(c(min(property-property[reference_compound]),
max(property-property[reference_compound]) ) )

#Distance_matrix[,1] <- NULL

#average_distance <- mean(c(min(Distance_matrix[, reference_compound]),  
#max(Distance_matrix[, reference_compound]) ) )

average_distance <- mean(c(min(euclid_distance[,2]-euclid_distance[reference_compound,2]),
max(euclid_distance[,2]-euclid_distance[reference_compound,2] ) ) )

xaxis <- vector_values(average_distance)
yaxis <- vector_values(average_shift)

png(file = paste("Dist_SA_chart_",df[reference_compound,1],".png")
,width=400, height=500)

SALI_plot <- plot(x = euclid_distance[,2], y = property-property[reference_compound],
	type = "p", 
	main = "Structure-Activity Chart", 
	ylab = "Activit change", xlab = paste("Distance ",df[reference_compound,1], sep =""),
   	col = "violet")

lines(xaxis, property-property[reference_compound], col = "black")
lines(euclid_distance[,2], yaxis, col = "black")

dev.off()

## splitting compounds into categories

SALI_categorized <- data.frame(df[,1],
 property-property[reference_compound],
 euclid_distance[,2])
colnames(SALI_categorized) <- c("Name", "Activity shift",
paste("Distance ",df[reference_compound,1],sep ="") ) 

output_category1 <- 0
output_category2 <- 0
output_category3 <- 0
output_category4 <- 0

for (i in 1:nrow(SALI_categorized)) {
  
if (SALI_categorized[i,2] >= average_shift && SALI_categorized[i,3] >= average_distance)
{ output_category2[i] <- as.character(SALI_categorized[i,1]) } 
  
if (SALI_categorized[i,2] >= average_shift && SALI_categorized[i,3] <= average_distance) 
  { output_category1[i] <- as.character(SALI_categorized[i,1]) } 
 
if (SALI_categorized[i,2] <= average_shift && SALI_categorized[i,3] <= average_distance) 
  { output_category3[i] <- as.character(SALI_categorized[i,1]) } 
   
if (SALI_categorized[i,2] <= average_shift && SALI_categorized[i,3] >= average_distance) 
  {output_category4[i] <- as.character(SALI_categorized[i,1])} 
}   

## remove NAs and zeros
output_category1 <- output_category1[output_category1 != 0 & !is.na(output_category1)]
output_category2 <- output_category2[output_category2 != 0 & !is.na(output_category2)]
output_category3 <- output_category3[output_category3 != 0 & !is.na(output_category3)]
output_category4 <- output_category4[output_category4 != 0 & !is.na(output_category4)]

## Output

Overall_output <- data.frame( SALI_categorized[order(SALI_categorized[,1]),   ],
SALI[order(SALI[,2]),1],
Smiles_string[order(Smiles_string[,1]),2 ],
least_common_descriptor[order(least_common_descriptor[,1]), 2] )

colnames(Overall_output) <- c(colnames(SALI_categorized), "SALId", "SMILES string", "least common descriptor")

## the threshold value

SALI_threshold <- mean(SALI[!is.nan(SALI[,1]) & !is.infinite(SALI[,1]),1])+ 
sd(SALI[!is.nan(SALI[,1]) & !is.infinite(SALI[,1]),1])

## selecting the most discontinuous 

highest_SALI <- data.frame(SALI[SALI[,1] > SALI_threshold,], SALI_threshold)

## saving everything

Mapping_results1_filename <- paste("Distance_Mapping_results_", df[reference_compound,1],
 "_cat1", ".csv", sep ="")
Mapping_results2_filename <- paste("Distance_Mapping_results_",df[reference_compound,1],
 "_cat2", ".csv", sep ="")
Mapping_results3_filename <- paste("Distance_Mapping_results_",df[reference_compound,1],
 "_cat3", ".csv", sep ="")
Mapping_results4_filename <- paste("Distance_Mapping_results_",df[reference_compound,1], 
 "_cat4", ".csv", sep ="")
Overall_results_filename <- paste("Overall_results_distance",df[reference_compound,1], 
  ".csv", sep ="")
highest_SALI_filename <- paste("highest_SALI_distance",df[reference_compound,1], 
  ".csv", sep ="")


write.csv(output_category1, file = Mapping_results1_filename)
write.csv(output_category2, file = Mapping_results2_filename)
write.csv(output_category3, file = Mapping_results3_filename)
write.csv(output_category4, file = Mapping_results4_filename)
write.csv(Overall_output, file = Overall_results_filename)
write.csv(highest_SALI, file = highest_SALI_filename)

}

setwd(original_dir)

svalue(status_bar) <- ""

