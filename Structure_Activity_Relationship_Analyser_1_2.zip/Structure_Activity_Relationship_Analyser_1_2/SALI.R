###############################################################################

## Status bar

svalue(status_bar) <- "Calculating..."

###SALI calculation
SALI <- 0

for (i in 1:nrow(df))
{
SALI[i] <- (abs(property[reference_compound] - property[i]))/(1 - Tanimoto[i,2]) 
}

SALI <- as.data.frame(SALI)
SALI[,2] <- df[,1]
SALI <- as.data.frame(SALI[order(SALI[,1], decreasing = TRUE), ])
colnames(SALI) <- c("",df[reference_compound,1])
SALI_filename <- paste("SALI_",df[reference_compound,1],".csv",
 sep ="")


new_window <- gwindow(title = "SALI", 
visible = TRUE, handler = NULL, toolkit = guiToolkit())

SALI_gtable <- gtable(SALI, 
container = new_window, handler = function(h,...) 
{dispose(h$obj)}, toolkit = guiToolkit())

svalue(status_bar) <- ""
		


