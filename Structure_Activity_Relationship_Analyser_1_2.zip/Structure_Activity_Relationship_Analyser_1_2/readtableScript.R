## Status bar
svalue(status_bar) <- "Uploading..."

## Uploading data table
df <- read.table(svalue(sometext), header=TRUE, sep="\t", check.names=FALSE, 
           as.is=TRUE, comment.char="", quote="", row.names=NULL)

## ordering by activity
#df <- as.data.frame(df[order(df[,2], decreasing = TRUE), ])

Smiles_string <- data.frame(df[,1],0)

## splitting the activity from descriptors
property <- df[,2]
df[,2] <- NULL
new_window <- gwindow(title = "Data Table", 
visible = TRUE, handler = NULL, toolkit = guiToolkit())

df_gtable <- gtable(df, container = new_window, handler = function(h,...) 
{dispose(h$obj)}, toolkit = guiToolkit())

svalue(status_bar) <- ""